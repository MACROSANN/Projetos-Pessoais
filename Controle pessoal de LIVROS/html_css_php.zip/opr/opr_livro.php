﻿<?php 
	require("../config/CRUD.php"); 
	$id_livro = isset($_POST["id"]) ? $_POST["id"]:	null;
	$acao 		= isset($_POST["acao"]) ? $_POST["acao"]:	"Inserir";

	$dados	= array(
				"id_editora" => trim(filter_input(INPUT_POST, "txt_id_editora")),
				"livro" => trim(filter_input(INPUT_POST, "txt_livro")),
				"autor" => trim(filter_input(INPUT_POST, "txt_autor"))
	);
	if($acao == "Inserir"){
		inserir("livro", $dados);
	}
	if($acao == "Editar"){
		alterar("livro", $dados, "id_livro = ".$id_livro);
	}
	if($acao == "Excluir"){
		deletar("livro", "id_livro = ".$id_livro);
	}
	header("location: ../index.php?link=4");
?>
