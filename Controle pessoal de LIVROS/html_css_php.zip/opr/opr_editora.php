﻿<?php 
	require("../config/CRUD.php"); 
	$id_editora = isset($_POST["id"]) ? $_POST["id"]:	null;
	$acao 		= isset($_POST["acao"]) ? $_POST["acao"]:	"Inserir";

	$dados	= array(
				"editora" => trim(filter_input(INPUT_POST, "txt_editora"))
	);
	if($acao == "Inserir"){
		inserir("editora", $dados);
	}
	if($acao == "Editar"){
		alterar("editora", $dados, "id_editora = ".$id_editora);
	}
	if($acao == "Excluir"){
		deletar("editora", "id_editora = ".$id_editora);
	}
	header("location: ../index.php?link=2");
?>
