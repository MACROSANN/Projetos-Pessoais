﻿			<div class="base-menu">
				<a href="index.php" class="logo"><img src="img/logo.png"></a>
				<ul>
					<li><a href="index.php"><i class="icone home"></i>Página inicial</a></li>
					<li><a href="index.php?link=2"><i class="icone lsteditora"></i>Lista editora</a></li>
					<li><a href="index.php?link=3"><i class="icone editora"></i>Nova editora</a></li>
					<li><a href="index.php?link=4"><i class="icone lstlivro"></i>Lista livros</a></li>
					<li><a href="index.php?link=5"><i class="icone livro"></i>Novo livro</a></li>
				</ul>
			</div>
