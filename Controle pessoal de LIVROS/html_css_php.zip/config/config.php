﻿<?php
//configurações para conexão com o banco de dados	
	define("SERVIDOR","localhost");
	define("USUARIO","root");
	define("SENHA","");
	define("BANCO","livros");
	define("CHARSET","utf8");
?>